
import React from 'react';

const FlashIcon: React.FC<{ className?: string; on: boolean }> = ({ className = "w-6 h-6", on }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    {on ? (
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
    ) : (
      <>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2 2l20 20" />
      </>
    )}
  </svg>
);

export default FlashIcon;
