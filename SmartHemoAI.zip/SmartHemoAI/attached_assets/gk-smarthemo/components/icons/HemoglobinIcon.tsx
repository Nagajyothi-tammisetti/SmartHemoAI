
import React from 'react';

const HemoglobinIcon: React.FC<{ className?: string }> = ({ className = "w-10 h-10" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
        <path d="M12 11.1c1.5 0 2.9-1.3 2.9-2.8s-1.3-2.8-2.9-2.8-2.9 1.3-2.9 2.8 1.3 2.8 2.9 2.8z"></path>
        <path d="M9.1 14.5c0-1.6 1.3-2.9 2.9-2.9s2.9 1.3 2.9 2.9v0c0 1.6-1.3 2.9-2.9 2.9s-2.9-1.3-2.9-2.9z"></path>
    </svg>
);

export default HemoglobinIcon;
