
import React from 'react';

const CbcIcon: React.FC<{ className?: string }> = ({ className = "w-10 h-10" }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"></path>
        <circle cx="10" cy="10" r="1"></circle>
        <circle cx="14" cy="14" r="1.5"></circle>
        <circle cx="15" cy="9" r="0.5"></circle>
        <circle cx="9" cy="15" r="1"></circle>
    </svg>
);

export default CbcIcon;
