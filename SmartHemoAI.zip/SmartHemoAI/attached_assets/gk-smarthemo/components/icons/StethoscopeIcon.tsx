
import React from 'react';

const StethoscopeIcon: React.FC<{ className?: string }> = ({ className = "w-16 h-16" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M18 8C18 5.79086 16.2091 4 14 4C11.7909 4 10 5.79086 10 8V14C10 16.2091 11.7909 18 14 18C16.2091 18 18 16.2091 18 14V11" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M14 18V21M14 21H12M14 21H16" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M6 8C6 5.79086 7.79086 4 10 4V4C12.2091 4 14 5.79086 14 8V11" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M5 16C5 17.1046 5.89543 18 7 18C8.10457 18 9 17.1046 9 16C9 14.8954 8.10457 14 7 14C5.89543 14 5 14.8954 5 16Z" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M14 11H17C18.1046 11 19 10.1046 19 9V7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M5 8.5H3V11.5H5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export default StethoscopeIcon;
