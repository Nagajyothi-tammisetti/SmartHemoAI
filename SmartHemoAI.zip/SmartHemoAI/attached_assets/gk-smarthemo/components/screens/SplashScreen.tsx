
import React, { useEffect } from 'react';
import { Screen } from '../../types';
import StethoscopeIcon from '../icons/StethoscopeIcon';

interface SplashScreenProps {
  setCurrentScreen: (screen: Screen) => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ setCurrentScreen }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      setCurrentScreen(Screen.Home);
    }, 2500); // Show splash for 2.5 seconds

    return () => clearTimeout(timer); // Cleanup timer on unmount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="flex flex-col items-center justify-center h-full bg-gradient-to-br from-primary-light to-white dark:from-primary-dark/20 dark:to-background-dark animate-fade-in">
      <div className="relative flex items-center justify-center">
        <div className="absolute w-32 h-32 bg-primary-default/20 rounded-full animate-ping"></div>
        <div className="relative p-6 bg-white dark:bg-gray-800 rounded-full shadow-2xl">
           <StethoscopeIcon className="w-24 h-24 text-primary-default" />
        </div>
      </div>
      <h1 className="mt-8 text-4xl font-extrabold text-text-light dark:text-text-dark tracking-tight">
        GK SmartHemo
      </h1>
      <p className="text-text-lightMuted dark:text-text-darkMuted">Your Health, Analyzed.</p>
    </div>
  );
};

export default SplashScreen;
