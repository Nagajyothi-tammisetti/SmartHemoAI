
import React, { useState } from 'react';
import { Screen } from '../../types';
import FlashIcon from '../icons/FlashIcon';
import GalleryIcon from '../icons/GalleryIcon';
import SunIcon from '../icons/SunIcon';

interface CameraScreenProps {
  setCurrentScreen: (screen: Screen) => void;
}

const CameraScreen: React.FC<CameraScreenProps> = ({ setCurrentScreen }) => {
  const [flashOn, setFlashOn] = useState(false);

  return (
    <div className="relative h-full w-full bg-black flex flex-col">
      <div className="absolute top-0 left-0 w-full p-4 bg-black bg-opacity-50 z-10">
        <h1 className="text-white text-xl font-bold text-center">Capture Test Strip</h1>
      </div>

      {/* Mock Camera Feed */}
      <div className="flex-grow w-full h-full bg-gray-900 flex items-center justify-center">
        <p className="text-gray-500">Camera Feed</p>
      </div>

      {/* Overlay */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-11/12 h-1/4 border-4 border-dashed border-white rounded-lg opacity-75">
          <div className="relative w-full h-full">
            <div className="absolute -top-1 -left-1 w-8 h-8 border-t-4 border-l-4 border-primary-default"></div>
            <div className="absolute -top-1 -right-1 w-8 h-8 border-t-4 border-r-4 border-primary-default"></div>
            <div className="absolute -bottom-1 -left-1 w-8 h-8 border-b-4 border-l-4 border-primary-default"></div>
            <div className="absolute -bottom-1 -right-1 w-8 h-8 border-b-4 border-r-4 border-primary-default"></div>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 w-full p-6 bg-black bg-opacity-50 z-10">
        <div className="flex items-center justify-around">
            <button className="p-3 bg-gray-700 bg-opacity-50 rounded-full text-white">
                <GalleryIcon />
            </button>
            <button onClick={() => setCurrentScreen(Screen.Analysis)} className="w-20 h-20 bg-white rounded-full border-4 border-primary-light shadow-lg transform transition hover:scale-105">
            </button>
            <div className="flex flex-col space-y-4">
                 <button onClick={() => setFlashOn(!flashOn)} className="p-3 bg-gray-700 bg-opacity-50 rounded-full text-white">
                    <FlashIcon on={flashOn} />
                </button>
                <button className="p-3 bg-gray-700 bg-opacity-50 rounded-full text-white">
                    <SunIcon />
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default CameraScreen;
