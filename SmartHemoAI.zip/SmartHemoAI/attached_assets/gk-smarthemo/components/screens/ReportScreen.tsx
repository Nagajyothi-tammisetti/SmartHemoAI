
import React from 'react';
import { Screen, PatientDetails } from '../../types';
import BottomNav from '../common/BottomNav';
import Card from '../common/Card';

interface ReportScreenProps {
  setCurrentScreen: (screen: Screen) => void;
  testType: string | null;
  patientDetails: PatientDetails | null;
}

const ReportItem: React.FC<{ label: string; value: string; range: string; isNormal: boolean }> = ({ label, value, range, isNormal }) => (
  <div className="flex justify-between items-center py-3 border-b border-gray-200 dark:border-gray-700 last:border-b-0">
    <div>
      <p className="font-semibold text-text-light dark:text-text-dark">{label}</p>
      <p className="text-xs text-text-lightMuted dark:text-text-darkMuted">Ref: {range}</p>
    </div>
    <div className="flex items-center space-x-2">
      <p className={`font-bold text-lg ${isNormal ? 'text-green-500' : 'text-red-500'}`}>{value}</p>
      <span className={`w-3 h-3 rounded-full ${isNormal ? 'bg-green-500' : 'bg-red-500'}`}></span>
    </div>
  </div>
);

const ReportScreen: React.FC<ReportScreenProps> = ({ setCurrentScreen, testType, patientDetails }) => {
  return (
    <div className="flex flex-col h-full bg-surface-light dark:bg-surface-dark">
      <header className="p-6">
        <h1 className="text-2xl font-bold text-text-light dark:text-text-dark text-center">Diagnostic Report</h1>
      </header>
      
      <main className="flex-grow p-6 space-y-4 overflow-y-auto pb-24">
        <Card>
          <div className="space-y-2 text-sm text-text-lightMuted dark:text-text-darkMuted">
            <div className="flex justify-between"><span>Patient Name:</span><span className="font-medium text-text-light dark:text-text-dark">{patientDetails?.name || 'N/A'}</span></div>
            <div className="flex justify-between"><span>Age:</span><span className="font-medium text-text-light dark:text-text-dark">{patientDetails?.age || 'N/A'}</span></div>
            {patientDetails?.id && <div className="flex justify-between"><span>Patient ID:</span><span className="font-medium text-text-light dark:text-text-dark">{patientDetails.id}</span></div>}
            <div className="flex justify-between"><span>Date:</span><span className="font-medium text-text-light dark:text-text-dark">{new Date().toLocaleDateString()}</span></div>
            <div className="flex justify-between"><span>Test Type:</span><span className="font-medium text-text-light dark:text-text-dark">{testType || "Glucose Test"}</span></div>
          </div>
        </Card>

        <Card>
            <h3 className="text-lg font-bold mb-2 text-text-light dark:text-text-dark">Results</h3>
            <div className="space-y-2">
                <ReportItem label="Glucose Level" value="95 mg/dL" range="70-100 mg/dL" isNormal={true} />
                <ReportItem label="RBC Count" value="4.1 M/µL" range="4.2-5.9 M/µL" isNormal={false} />
                <ReportItem label="WBC Count" value="7,500 /µL" range="4,500-11,000 /µL" isNormal={true} />
                <ReportItem label="Hemoglobin" value="14.2 g/dL" range="13.5-17.5 g/dL" isNormal={true} />
            </div>
        </Card>

        <div className="flex space-x-4 pt-4">
            <button className="w-full py-3 bg-primary-default text-white font-bold rounded-lg shadow-md hover:bg-primary-dark transition-colors">Download PDF</button>
            <button className="w-full py-3 bg-secondary text-white font-bold rounded-lg shadow-md hover:bg-green-600 transition-colors">Send to Doctor</button>
        </div>
      </main>

      <BottomNav activeScreen={Screen.Report} setCurrentScreen={setCurrentScreen} />
    </div>
  );
};

export default ReportScreen;
