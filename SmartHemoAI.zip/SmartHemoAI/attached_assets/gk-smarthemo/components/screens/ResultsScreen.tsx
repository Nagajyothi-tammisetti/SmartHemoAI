
import React from 'react';
import { Screen } from '../../types';
import Card from '../common/Card';

interface ResultsScreenProps {
  setCurrentScreen: (screen: Screen) => void;
  testType: string | null;
}

const ResultsScreen: React.FC<ResultsScreenProps> = ({ setCurrentScreen, testType }) => {
  const isNormal = true; // Mock result

  return (
    <div className="flex flex-col h-full bg-surface-light dark:bg-surface-dark p-6 space-y-6">
      <header>
        <h1 className="text-3xl font-bold text-text-light dark:text-text-dark text-center">Test Results</h1>
        <p className="text-center text-text-lightMuted dark:text-text-darkMuted">{testType || "Glucose Test"}</p>
      </header>

      <Card className="text-center">
        <h3 className="text-lg font-bold text-text-light dark:text-text-dark mb-4">AI Interpretation</h3>
        <div className={`inline-flex items-center space-x-2 px-6 py-3 rounded-full ${isNormal ? 'bg-green-100 dark:bg-green-900' : 'bg-red-100 dark:bg-red-900'}`}>
          {isNormal ? 
            <span className="w-4 h-4 rounded-full bg-green-500"></span> :
            <span className="w-4 h-4 rounded-full bg-red-500"></span>
          }
          <p className={`text-2xl font-extrabold ${isNormal ? 'text-green-600 dark:text-green-300' : 'text-red-600 dark:text-red-300'}`}>
            {isNormal ? "Normal" : "Abnormal"}
          </p>
        </div>
        <p className="text-sm text-text-lightMuted dark:text-text-darkMuted mt-4">
            The analysis indicates your levels are within the normal reference range.
        </p>
      </Card>
      
      <Card>
        <h3 className="text-lg font-bold text-text-light dark:text-text-dark mb-2">Color Intensity</h3>
        <div className="flex items-center justify-around text-center">
            <div>
                <div className="w-16 h-16 rounded-full bg-red-400 mx-auto mb-1 border-2 border-white dark:border-gray-700 shadow-sm"></div>
                <p className="font-bold text-red-500">RGB</p>
                <p className="text-xs text-text-lightMuted dark:text-text-darkMuted">180, 80, 80</p>
            </div>
            <div>
                <div className="w-16 h-16 rounded-full bg-green-400 mx-auto mb-1 border-2 border-white dark:border-gray-700 shadow-sm"></div>
                <p className="font-bold text-green-500">HEX</p>
                <p className="text-xs text-text-lightMuted dark:text-text-darkMuted">#B45050</p>
            </div>
        </div>
      </Card>

      <div className="flex-grow"></div>

      <div className="space-y-3">
        <button 
          onClick={() => setCurrentScreen(Screen.Report)}
          className="w-full py-4 bg-primary-default text-white font-bold rounded-xl shadow-md hover:bg-primary-dark transition-colors"
        >
          Save Report
        </button>
        <button className="w-full py-3 text-primary-default font-bold rounded-lg hover:bg-primary-light dark:hover:bg-primary-dark/20 transition-colors">
          Share
        </button>
      </div>
    </div>
  );
};

export default ResultsScreen;
