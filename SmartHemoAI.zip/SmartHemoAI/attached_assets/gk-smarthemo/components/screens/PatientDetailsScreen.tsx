
import React, { useState } from 'react';
import { Screen, PatientDetails } from '../../types';
import Card from '../common/Card';

interface PatientDetailsScreenProps {
  setCurrentScreen: (screen: Screen) => void;
  setPatientDetails: (details: PatientDetails) => void;
}

const InputField: React.FC<{
    label: string;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    placeholder: string;
    type?: string;
}> = ({ label, value, onChange, placeholder, type = 'text' }) => (
    <div>
        <label className="block text-sm font-medium text-text-lightMuted dark:text-text-darkMuted mb-1">{label}</label>
        <input
            type={type}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            className="w-full px-4 py-3 bg-gray-100 dark:bg-gray-700 border-2 border-transparent rounded-lg text-text-light dark:text-text-dark focus:outline-none focus:ring-2 focus:ring-primary-default focus:border-transparent transition"
        />
    </div>
);

const PatientDetailsScreen: React.FC<PatientDetailsScreenProps> = ({ setCurrentScreen, setPatientDetails }) => {
    const [name, setName] = useState('');
    const [age, setAge] = useState('');
    const [id, setId] = useState('');

    const handleSubmit = () => {
        if (name && age) {
            setPatientDetails({ name, age, id });
            setCurrentScreen(Screen.Camera);
        } else {
            alert('Please fill in Patient Name and Age.');
        }
    };

    return (
        <div className="flex flex-col h-full bg-surface-light dark:bg-surface-dark p-6">
            <header className="text-center mb-8">
                <h1 className="text-3xl font-bold text-text-light dark:text-text-dark">Patient Details</h1>
                <p className="text-text-lightMuted dark:text-text-darkMuted mt-1">Enter patient information before starting the test.</p>
            </header>

            <main className="flex-grow flex flex-col justify-center space-y-6">
                <Card className="!p-8">
                    <div className="space-y-5">
                        <InputField
                            label="Patient Name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            placeholder="e.g., John Doe"
                        />
                        <InputField
                            label="Age"
                            value={age}
                            onChange={(e) => setAge(e.target.value)}
                            placeholder="e.g., 34"
                            type="number"
                        />
                         <InputField
                            label="Patient ID (Optional)"
                            value={id}
                            onChange={(e) => setId(e.target.value)}
                            placeholder="e.g., P123456"
                        />
                    </div>
                </Card>
            </main>

            <div className="pb-4">
                 <button
                    onClick={handleSubmit}
                    className="w-full py-4 bg-primary-default text-white font-bold rounded-xl shadow-md hover:bg-primary-dark transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                    disabled={!name || !age}
                >
                    Continue to Capture
                </button>
                <button
                    onClick={() => setCurrentScreen(Screen.Home)}
                    className="w-full py-3 mt-2 text-primary-default font-bold rounded-lg hover:bg-primary-light dark:hover:bg-primary-dark/20 transition-colors"
                >
                    Back to Home
                </button>
            </div>
        </div>
    );
};

export default PatientDetailsScreen;
