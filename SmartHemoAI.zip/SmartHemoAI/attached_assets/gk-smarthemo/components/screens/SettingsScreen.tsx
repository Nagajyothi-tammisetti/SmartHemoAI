
import React from 'react';
import { Screen } from '../../types';
import BottomNav from '../common/BottomNav';
import Card from '../common/Card';
import SunIcon from '../icons/SunIcon';
import MoonIcon from '../icons/MoonIcon';

interface SettingsScreenProps {
  setCurrentScreen: (screen: Screen) => void;
  darkMode: boolean;
  setDarkMode: (value: boolean) => void;
}

const SettingsItem: React.FC<{ label: string, children?: React.ReactNode }> = ({ label, children }) => (
    <div className="flex justify-between items-center py-4">
        <span className="text-text-light dark:text-text-dark font-medium">{label}</span>
        <div>{children}</div>
    </div>
);

const DarkModeToggle: React.FC<{ darkMode: boolean; setDarkMode: (value: boolean) => void }> = ({ darkMode, setDarkMode }) => (
    <button onClick={() => setDarkMode(!darkMode)} className={`relative inline-flex items-center h-8 w-14 rounded-full transition-colors duration-300 ${darkMode ? 'bg-primary-default' : 'bg-gray-300'}`}>
        <span className={`absolute left-1 transition-transform duration-300 transform ${darkMode ? 'translate-x-6' : 'translate-x-0'}`}>
          <span className="flex items-center justify-center w-6 h-6 rounded-full bg-white shadow-md">
            {darkMode ? <MoonIcon className="w-4 h-4 text-primary-default"/> : <SunIcon className="w-4 h-4 text-gray-500" />}
          </span>
        </span>
    </button>
);

const SettingsScreen: React.FC<SettingsScreenProps> = ({ setCurrentScreen, darkMode, setDarkMode }) => {
  return (
    <div className="flex flex-col h-full bg-surface-light dark:bg-surface-dark">
      <header className="p-6">
        <h1 className="text-3xl font-bold text-text-light dark:text-text-dark">Settings</h1>
      </header>
      
      <main className="flex-grow p-6 pt-0 space-y-4 overflow-y-auto pb-24">
        <Card className="flex items-center space-x-4">
          <img src="https://picsum.photos/100" alt="User Profile" className="w-16 h-16 rounded-full" />
          <div>
            <h2 className="text-xl font-bold text-text-light dark:text-text-dark">Jane Doe</h2>
            <p className="text-text-lightMuted dark:text-text-darkMuted">jane.doe@example.com</p>
          </div>
        </Card>
        
        <Card className="divide-y divide-gray-200 dark:divide-gray-700 !p-0">
           <div className="px-6">
                <SettingsItem label="Device Calibration" />
                <SettingsItem label="Language" />
                <SettingsItem label="Units (mg/dL)" />
                <SettingsItem label="Dark Mode">
                    <DarkModeToggle darkMode={darkMode} setDarkMode={setDarkMode} />
                </SettingsItem>
           </div>
        </Card>
        
        <Card className="divide-y divide-gray-200 dark:divide-gray-700 !p-0">
           <div className="px-6">
                <SettingsItem label="About App" />
                <SettingsItem label="Help & Support" />
           </div>
        </Card>

      </main>

      <BottomNav activeScreen={Screen.Settings} setCurrentScreen={setCurrentScreen} />
    </div>
  );
};

export default SettingsScreen;
