
export enum Screen {
  Splash,
  Home,
  PatientDetails,
  Camera,
  Analysis,
  Results,
  Report,
  Settings,
}

export enum TestType {
    Glucose = "Glucose Test",
    CBC = "Complete Blood Count (CBC)",
    Hemoglobin = "Hemoglobin"
}

export interface PatientDetails {
  name: string;
  age: string;
  id?: string;
}
