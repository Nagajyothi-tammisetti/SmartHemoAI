
import React, { useState, useEffect } from 'react';
import { Screen, PatientDetails } from './types';
import SplashScreen from './components/screens/SplashScreen';
import HomeScreen from './components/screens/HomeScreen';
import PatientDetailsScreen from './components/screens/PatientDetailsScreen';
import CameraScreen from './components/screens/CameraScreen';
import AnalysisScreen from './components/screens/AnalysisScreen';
import ResultsScreen from './components/screens/ResultsScreen';
import ReportScreen from './components/screens/ReportScreen';
import SettingsScreen from './components/screens/SettingsScreen';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.Splash);
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [selectedTest, setSelectedTest] = useState<string | null>(null);
  const [patientDetails, setPatientDetails] = useState<PatientDetails | null>(null);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const renderScreen = () => {
    switch (currentScreen) {
      case Screen.Splash:
        return <SplashScreen setCurrentScreen={setCurrentScreen} />;
      case Screen.Home:
        return <HomeScreen setCurrentScreen={setCurrentScreen} setSelectedTest={setSelectedTest} />;
      case Screen.PatientDetails:
        return <PatientDetailsScreen setCurrentScreen={setCurrentScreen} setPatientDetails={setPatientDetails} />;
      case Screen.Camera:
        return <CameraScreen setCurrentScreen={setCurrentScreen} />;
      case Screen.Analysis:
        return <AnalysisScreen setCurrentScreen={setCurrentScreen} />;
      case Screen.Results:
        return <ResultsScreen setCurrentScreen={setCurrentScreen} testType={selectedTest} />;
      case Screen.Report:
        return <ReportScreen setCurrentScreen={setCurrentScreen} testType={selectedTest} patientDetails={patientDetails} />;
      case Screen.Settings:
        return <SettingsScreen setCurrentScreen={setCurrentScreen} darkMode={darkMode} setDarkMode={setDarkMode} />;
      default:
        return <HomeScreen setCurrentScreen={setCurrentScreen} setSelectedTest={setSelectedTest} />;
    }
  };

  return (
    <div className="bg-background-light dark:bg-background-dark min-h-screen font-sans">
      <div className="w-full max-w-md mx-auto h-screen shadow-2xl bg-surface-light dark:bg-surface-dark overflow-hidden">
        {renderScreen()}
      </div>
    </div>
  );
};

export default App;
