import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const calibrationSamples = pgTable("calibration_samples", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  trueColorHex: text("true_color_hex").notNull(),
  trueColorName: text("true_color_name").notNull(),
  lightSource: text("light_source").notNull(),
  lightIntensity: integer("light_intensity").notNull(),
  capturedImage: text("captured_image"), // base64 encoded image
  detectedColorHex: text("detected_color_hex").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const testResults = pgTable("test_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  detectedColors: jsonb("detected_colors").notNull(), // array of color objects
  overallIntensity: decimal("overall_intensity", { precision: 5, scale: 2 }).notNull(),
  lightCondition: text("light_condition").notNull(),
  stripPosition: text("strip_position").notNull(),
  glucoseRange: text("glucose_range"),
  predictionConfidence: decimal("prediction_confidence", { precision: 5, scale: 2 }).notNull(),
  imageData: text("image_data"), // base64 encoded captured image
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const environmentReadings = pgTable("environment_readings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  temperature: decimal("temperature", { precision: 4, scale: 1 }).notNull(),
  lightIntensity: integer("light_intensity").notNull(),
  humidity: decimal("humidity", { precision: 4, scale: 1 }).notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Zod schemas
export const insertCalibrationSampleSchema = createInsertSchema(calibrationSamples).pick({
  trueColorHex: true,
  trueColorName: true,
  lightSource: true,
  lightIntensity: true,
  capturedImage: true,
  detectedColorHex: true,
});

export const insertTestResultSchema = createInsertSchema(testResults).pick({
  detectedColors: true,
  overallIntensity: true,
  lightCondition: true,
  stripPosition: true,
  glucoseRange: true,
  predictionConfidence: true,
  imageData: true,
});

export const insertEnvironmentReadingSchema = createInsertSchema(environmentReadings).pick({
  temperature: true,
  lightIntensity: true,
  humidity: true,
});

// Types
export type CalibrationSample = typeof calibrationSamples.$inferSelect;
export type InsertCalibrationSample = z.infer<typeof insertCalibrationSampleSchema>;

export type TestResult = typeof testResults.$inferSelect;
export type InsertTestResult = z.infer<typeof insertTestResultSchema>;

export type EnvironmentReading = typeof environmentReadings.$inferSelect;
export type InsertEnvironmentReading = z.infer<typeof insertEnvironmentReadingSchema>;

// Color analysis types
export interface DetectedColor {
  name: string;
  hex: string;
  confidence: number;
  intensity: number;
}

export interface ColorAnalysisResult {
  detectedColors: DetectedColor[];
  overallIntensity: number;
  lightCondition: string;
  stripPosition: string;
  glucoseRange?: string;
  predictionConfidence: number;
}

export interface CalibrationData {
  samples: CalibrationSample[];
  accuracy: number;
  lastUpdate: Date;
  modelMetrics: {
    precision: number;
    recall: number;
    f1Score: number;
    mse: number;
  };
}
