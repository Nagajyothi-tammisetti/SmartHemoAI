export interface RGBColor {
  r: number;
  g: number;
  b: number;
}

export interface HSLColor {
  h: number;
  s: number;
  l: number;
}

export function hexToRgb(hex: string): RGBColor | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;
}

export function rgbToHex(r: number, g: number, b: number): string {
  return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}

export function rgbToHsl(r: number, g: number, b: number): HSLColor {
  r /= 255;
  g /= 255;
  b /= 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h: number;
  let s: number;
  const l = (max + min) / 2;

  if (max === min) {
    h = s = 0; // achromatic
  } else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);

    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
      default: h = 0;
    }

    h /= 6;
  }

  return {
    h: Math.round(h * 360),
    s: Math.round(s * 100),
    l: Math.round(l * 100)
  };
}

export function calculateColorIntensity(hex: string): number {
  const rgb = hexToRgb(hex);
  if (!rgb) return 0;

  // Calculate relative luminance
  const { r, g, b } = rgb;
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  
  return Math.round(luminance * 100);
}

export function getColorName(hex: string): string {
  const rgb = hexToRgb(hex);
  if (!rgb) return "Unknown";

  const { r, g, b } = rgb;

  // Simple color classification
  if (r > g && r > b) {
    if (r > 200 && g < 100 && b < 100) return "Red";
    if (r > 150 && g > 100 && b < 100) return "Orange";
    if (r > 100 && g > 100 && b > 100) return "Pink";
  }
  
  if (g > r && g > b) {
    if (g > 200 && r < 100 && b < 100) return "Green";
    if (g > 150 && r > 100 && b < 100) return "Yellow";
  }
  
  if (b > r && b > g) {
    if (b > 200 && r < 100 && g < 100) return "Blue";
    if (b > 150 && r > 100 && g > 100) return "Purple";
  }

  // Grayscale detection
  const avg = (r + g + b) / 3;
  const variance = Math.sqrt(((r - avg) ** 2 + (g - avg) ** 2 + (b - avg) ** 2) / 3);
  
  if (variance < 20) {
    if (avg < 50) return "Black";
    if (avg > 200) return "White";
    return "Gray";
  }

  return "Mixed";
}

export function extractColorsFromImageData(imageData: ImageData): string[] {
  const colors: Map<string, number> = new Map();
  const data = imageData.data;
  
  // Sample every 4th pixel to improve performance
  for (let i = 0; i < data.length; i += 16) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const a = data[i + 3];
    
    // Skip transparent pixels
    if (a < 128) continue;
    
    const hex = rgbToHex(r, g, b);
    colors.set(hex, (colors.get(hex) || 0) + 1);
  }
  
  // Sort by frequency and return top 10
  return Array.from(colors.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([hex]) => hex);
}

export function findClosestCalibrationColor(targetHex: string, calibrationColors: Array<{ hex: string; name: string }>): { color: string; confidence: number } {
  let bestMatch = calibrationColors[0];
  let bestDistance = Infinity;
  
  const targetRgb = hexToRgb(targetHex);
  if (!targetRgb) return { color: "Unknown", confidence: 0 };
  
  for (const calibrationColor of calibrationColors) {
    const calibrationRgb = hexToRgb(calibrationColor.hex);
    if (!calibrationRgb) continue;
    
    const distance = Math.sqrt(
      Math.pow(targetRgb.r - calibrationRgb.r, 2) +
      Math.pow(targetRgb.g - calibrationRgb.g, 2) +
      Math.pow(targetRgb.b - calibrationRgb.b, 2)
    );
    
    if (distance < bestDistance) {
      bestDistance = distance;
      bestMatch = calibrationColor;
    }
  }
  
  // Convert distance to confidence (0-100)
  const confidence = Math.max(0, Math.min(100, 100 - (bestDistance / 441) * 100));
  
  return {
    color: bestMatch.name,
    confidence: Math.round(confidence)
  };
}
