import calibrationDataset from "@assets/calibration_dataset (7)_1759242172948.json";

export interface CalibrationDataPoint {
  id: string;
  trueColorHex: string;
  trueColorName: string;
  lightSource: string;
  lightIntensity: number;
  capturedImage: string;
  detectedColorHex: string;
}

export const loadCalibrationData = (): CalibrationDataPoint[] => {
  return calibrationDataset as CalibrationDataPoint[];
};

export const getColorStatistics = () => {
  const data = loadCalibrationData();
  const colorGroups = data.reduce((acc, item) => {
    const colorName = item.trueColorName.toLowerCase();
    if (!acc[colorName]) {
      acc[colorName] = {
        name: item.trueColorName,
        trueHex: item.trueColorHex,
        samples: 0,
        detectedColors: [],
        totalIntensity: 0,
        accuracyCount: 0
      };
    }
    acc[colorName].samples++;
    acc[colorName].detectedColors.push(item.detectedColorHex);
    acc[colorName].totalIntensity += item.lightIntensity;
    
    // Simple accuracy calculation based on color similarity
    const accuracy = calculateColorSimilarity(item.trueColorHex, item.detectedColorHex);
    if (accuracy > 0.8) acc[colorName].accuracyCount++;
    
    return acc;
  }, {} as Record<string, any>);

  return Object.values(colorGroups).map((group: any) => ({
    name: group.name,
    hex: group.trueHex,
    samples: group.samples,
    avgIntensity: Math.round(group.totalIntensity / group.samples),
    accuracy: Math.round((group.accuracyCount / group.samples) * 100)
  }));
};

function calculateColorSimilarity(hex1: string, hex2: string): number {
  // Convert hex to RGB
  const rgb1 = hexToRgb(hex1);
  const rgb2 = hexToRgb(hex2);
  
  if (!rgb1 || !rgb2) return 0;
  
  // Calculate Euclidean distance
  const distance = Math.sqrt(
    Math.pow(rgb1.r - rgb2.r, 2) +
    Math.pow(rgb1.g - rgb2.g, 2) +
    Math.pow(rgb1.b - rgb2.b, 2)
  );
  
  // Normalize to 0-1 scale (max distance is ~441)
  return Math.max(0, 1 - (distance / 441));
}

function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;
}
