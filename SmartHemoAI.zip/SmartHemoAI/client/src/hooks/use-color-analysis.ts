import { useState, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { DetectedColor, ColorAnalysisResult } from "@shared/schema";
import { 
  extractColorsFromImageData, 
  findClosestCalibrationColor, 
  calculateColorIntensity,
  getColorName 
} from "@/lib/color-utils";
import { 
  colorIntensityModel, 
  stripDetectionModel, 
  lightConditionClassifier 
} from "@/lib/tensorflow-models";

export function useColorAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentAnalysis, setCurrentAnalysis] = useState<ColorAnalysisResult | null>(null);
  const queryClient = useQueryClient();

  // Fetch calibration samples for color matching
  const { data: calibrationSamples = [] } = useQuery<any[]>({
    queryKey: ['/api/calibration-samples'],
  });

  const analyzeImageMutation = useMutation({
    mutationFn: async (data: { imageData: string; lightCondition?: string }) =>
      apiRequest("POST", "/api/analyze-image", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/test-results'] });
    }
  });

  const analyzeImage = useCallback(async (
    imageData: ImageData,
    lightCondition?: string
  ): Promise<ColorAnalysisResult | null> => {
    setIsAnalyzing(true);
    
    try {
      // Extract colors from image
      const extractedColors = extractColorsFromImageData(imageData);
      
      // Detect test strip using YOLO model
      const stripDetection = await stripDetectionModel.detectStrip(imageData);
      
      // Classify light condition if not provided
      const lightClassification = lightCondition 
        ? { condition: lightCondition, confidence: 1.0 }
        : lightConditionClassifier.classifyLightCondition(imageData);

      // Create calibration color reference
      const calibrationColors = calibrationSamples.map(sample => ({
        hex: sample.trueColorHex,
        name: sample.trueColorName
      }));

      // Analyze each extracted color
      const detectedColors: DetectedColor[] = extractedColors.slice(0, 5).map(hex => {
        const colorMatch = findClosestCalibrationColor(hex, calibrationColors);
        const intensity = calculateColorIntensity(hex);
        
        return {
          name: colorMatch.color || getColorName(hex),
          hex,
          confidence: colorMatch.confidence,
          intensity
        };
      });

      // Calculate overall intensity
      const overallIntensity = detectedColors.reduce((sum, color) => sum + color.intensity, 0) / detectedColors.length;

      // Predict glucose level using ML model
      const colorDataForPrediction = detectedColors.map(color => [
        parseInt(color.hex.slice(1, 3), 16),
        parseInt(color.hex.slice(3, 5), 16),
        parseInt(color.hex.slice(5, 7), 16)
      ]);
      
      const mlPrediction = await colorIntensityModel.predictIntensity(colorDataForPrediction);

      const result: ColorAnalysisResult = {
        detectedColors,
        overallIntensity: Math.round(overallIntensity),
        lightCondition: lightClassification.condition,
        stripPosition: stripDetection ? "Centered" : "Not Detected",
        glucoseRange: `${Math.round(mlPrediction.glucoseLevel - 5)}-${Math.round(mlPrediction.glucoseLevel + 5)} mg/dL`,
        predictionConfidence: Math.round(mlPrediction.confidence * 100)
      };

      setCurrentAnalysis(result);

      // Send to backend for storage
      const canvas = document.createElement('canvas');
      canvas.width = imageData.width;
      canvas.height = imageData.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.putImageData(imageData, 0, 0);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        
        await analyzeImageMutation.mutateAsync({
          imageData: dataUrl,
          lightCondition: result.lightCondition
        });
      }

      return result;
    } catch (error) {
      console.error('Color analysis failed:', error);
      return null;
    } finally {
      setIsAnalyzing(false);
    }
  }, [calibrationSamples, analyzeImageMutation]);

  const clearAnalysis = useCallback(() => {
    setCurrentAnalysis(null);
  }, []);

  return {
    isAnalyzing,
    currentAnalysis,
    analyzeImage,
    clearAnalysis
  };
}
