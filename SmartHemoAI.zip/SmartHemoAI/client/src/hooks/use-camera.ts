import { useState, useRef, useCallback, useEffect } from "react";

export interface CameraConfig {
  width: number;
  height: number;
  facingMode: "user" | "environment";
  exposureMode: "manual" | "auto";
  focusMode: "manual" | "auto";
}

export interface CapturedImage {
  dataUrl: string;
  imageData: ImageData;
  timestamp: Date;
}

export function useCamera() {
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [config, setConfig] = useState<CameraConfig>({
    width: 1920,
    height: 1080,
    facingMode: "environment",
    exposureMode: "auto",
    focusMode: "auto"
  });

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = useCallback(async () => {
    try {
      setError(null);
      
      const constraints: MediaStreamConstraints = {
        video: {
          width: { ideal: config.width },
          height: { ideal: config.height },
          facingMode: config.facingMode
        }
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setIsStreaming(true);
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to access camera";
      setError(errorMessage);
      setIsStreaming(false);
    }
  }, [config]);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    
    setIsStreaming(false);
  }, []);

  const captureImage = useCallback(async (): Promise<CapturedImage | null> => {
    if (!videoRef.current || !isStreaming) {
      setError("Camera not available");
      return null;
    }

    try {
      const video = videoRef.current;
      const canvas = canvasRef.current || document.createElement('canvas');
      const context = canvas.getContext('2d');

      if (!context) {
        throw new Error("Failed to get canvas context");
      }

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      context.drawImage(video, 0, 0, canvas.width, canvas.height);

      const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
      const imageData = context.getImageData(0, 0, canvas.width, canvas.height);

      return {
        dataUrl,
        imageData,
        timestamp: new Date()
      };
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to capture image";
      setError(errorMessage);
      return null;
    }
  }, [isStreaming]);

  const updateConfig = useCallback((newConfig: Partial<CameraConfig>) => {
    setConfig(prev => ({ ...prev, ...newConfig }));
  }, []);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  // Restart camera when config changes
  useEffect(() => {
    if (isStreaming) {
      stopCamera();
      setTimeout(startCamera, 100); // Small delay to ensure cleanup
    }
  }, [config, isStreaming, startCamera, stopCamera]);

  return {
    videoRef,
    canvasRef,
    isStreaming,
    error,
    config,
    startCamera,
    stopCamera,
    captureImage,
    updateConfig
  };
}
