
import { Screen } from '@shared/types';
import HomeIcon from './icons/HomeIcon';
import CameraIcon from './icons/CameraIcon';
import ReportIcon from './icons/ReportIcon';
import SettingsIcon from './icons/SettingsIcon';

interface BottomNavProps {
  activeScreen: Screen;
  setCurrentScreen: (screen: Screen) => void;
}

const NavItem: React.FC<{
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => {
  const activeClass = isActive ? 'text-primary-default' : 'text-text-lightMuted dark:text-text-darkMuted';
  return (
    <button onClick={onClick} className={`flex flex-col items-center justify-center space-y-1 transition-colors duration-200 ${activeClass} hover:text-primary-dark`}>
      {icon}
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
};

const BottomNav: React.FC<BottomNavProps> = ({ activeScreen, setCurrentScreen }) => {
  return (
    <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-lg">
      <div className="flex justify-around items-center h-16">
        <NavItem 
          icon={<HomeIcon />} 
          label="Home" 
          isActive={activeScreen === Screen.Home} 
          onClick={() => setCurrentScreen(Screen.Home)}
        />
        <NavItem 
          icon={<CameraIcon />} 
          label="Camera" 
          isActive={activeScreen === Screen.Camera} 
          onClick={() => setCurrentScreen(Screen.Camera)}
        />
        <NavItem 
          icon={<ReportIcon />} 
          label="Reports" 
          isActive={activeScreen === Screen.Report}
          onClick={() => setCurrentScreen(Screen.Report)}
        />
        <NavItem 
          icon={<SettingsIcon />} 
          label="Settings" 
          isActive={activeScreen === Screen.Settings}
          onClick={() => setCurrentScreen(Screen.Settings)}
        />
      </div>
    </div>
  );
};

export default BottomNav;
