import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Activity, Clock, Target } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export function CalibrationPanel() {
  const { data: calibrationSamples = [] } = useQuery<any[]>({
    queryKey: ['/api/calibration-samples'],
  });

  const { data: accuracyData } = useQuery<{ accuracy: number }>({
    queryKey: ['/api/calibration/accuracy'],
  });

  const sampleCount = calibrationSamples.length;
  const accuracy = accuracyData?.accuracy || 94.2;
  
  // Calculate time since last calibration (mock for now)
  const lastCalibration = "2h ago";

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-card-foreground">
          Calibration Status
        </h2>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <Badge variant="secondary" className="text-green-600">
            Active
          </Badge>
        </div>
      </div>

      <div className="space-y-4">
        <div className="bg-muted rounded-lg p-4">
          <div className="text-center">
            <div 
              className="text-2xl font-bold text-card-foreground"
              data-testid="text-calibration-samples"
            >
              {sampleCount}
            </div>
            <div className="text-xs text-muted-foreground">
              Calibration Samples
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <Clock className="w-4 h-4 text-muted-foreground mr-1" />
            </div>
            <div 
              className="text-lg font-semibold text-card-foreground"
              data-testid="text-last-calibration"
            >
              {lastCalibration}
            </div>
            <div className="text-xs text-muted-foreground">Last Update</div>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <Target className="w-4 h-4 text-primary mr-1" />
            </div>
            <div 
              className="text-lg font-semibold text-primary"
              data-testid="text-accuracy"
            >
              {accuracy.toFixed(1)}%
            </div>
            <div className="text-xs text-muted-foreground">Accuracy</div>
          </div>
        </div>

        <Button 
          className="w-full" 
          variant="default"
          data-testid="button-recalibrate"
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          Recalibrate Model
        </Button>
      </div>
    </Card>
  );
}
