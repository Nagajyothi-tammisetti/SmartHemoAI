import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { getColorStatistics } from "@/data/calibration-data";
import { Target, Activity, TrendingUp, Zap } from "lucide-react";

interface ColorReferenceCardProps {
  colorData: {
    name: string;
    hex: string;
    samples: number;
    avgIntensity: number;
    accuracy: number;
  };
}

function ColorReferenceCard({ colorData }: ColorReferenceCardProps) {
  return (
    <div className="bg-muted rounded-lg p-4">
      <div className="flex items-center space-x-3 mb-3">
        <div 
          className="w-12 h-12 rounded-lg border-2 border-border transition-all hover:border-primary hover:scale-105"
          style={{ backgroundColor: colorData.hex }}
          data-testid={`color-reference-${colorData.name.toLowerCase()}`}
        />
        <div>
          <div className="text-sm font-medium text-card-foreground">
            {colorData.name}
          </div>
          <div className="text-xs text-muted-foreground">
            {colorData.hex}
          </div>
        </div>
      </div>
      <div className="space-y-2">
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">Samples:</span>
          <span 
            className="text-card-foreground font-medium"
            data-testid={`text-samples-${colorData.name.toLowerCase()}`}
          >
            {colorData.samples}
          </span>
        </div>
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">Avg Intensity:</span>
          <span 
            className="text-card-foreground font-medium"
            data-testid={`text-intensity-${colorData.name.toLowerCase()}`}
          >
            {colorData.avgIntensity}%
          </span>
        </div>
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">Accuracy:</span>
          <span 
            className="text-green-600 font-medium"
            data-testid={`text-accuracy-${colorData.name.toLowerCase()}`}
          >
            {colorData.accuracy}%
          </span>
        </div>
      </div>
    </div>
  );
}

export function DatasetVisualization() {
  const [activeView, setActiveView] = useState("Color Map");
  
  const { data: modelMetrics } = useQuery<{
    precision: number;
    recall: number;
    f1Score: number;
    mse: number;
  }>({
    queryKey: ['/api/model/metrics'],
  });

  const colorStatistics = getColorStatistics();
  
  const defaultMetrics = {
    precision: 94.2,
    recall: 91.8,
    f1Score: 93.0,
    mse: 0.08
  };

  const metrics = modelMetrics || defaultMetrics;

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-card-foreground">
          Calibration Dataset Visualization
        </h2>
        <div className="flex items-center space-x-2">
          {["Color Map", "Light Conditions", "Intensity"].map((view) => (
            <Button
              key={view}
              variant={activeView === view ? "default" : "secondary"}
              size="sm"
              onClick={() => setActiveView(view)}
              data-testid={`button-view-${view.toLowerCase().replace(" ", "-")}`}
            >
              {view}
            </Button>
          ))}
        </div>
      </div>

      {activeView === "Color Map" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {colorStatistics.map((colorData) => (
            <ColorReferenceCard 
              key={colorData.name} 
              colorData={colorData} 
            />
          ))}
        </div>
      )}

      {activeView === "Light Conditions" && (
        <div className="mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {["Daylight", "LED", "Fluorescent", "Incandescent"].map((condition) => (
              <div key={condition} className="bg-muted rounded-lg p-4">
                <div className="text-sm font-medium text-card-foreground mb-2">
                  {condition}
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Samples:</span>
                    <span className="text-card-foreground font-medium">
                      {Math.floor(Math.random() * 20) + 10}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Avg Accuracy:</span>
                    <span className="text-green-600 font-medium">
                      {90 + Math.floor(Math.random() * 8)}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeView === "Intensity" && (
        <div className="mb-6">
          <div className="bg-muted rounded-lg p-4">
            <h3 className="text-sm font-medium text-card-foreground mb-4">
              Intensity Distribution
            </h3>
            <div className="grid grid-cols-5 gap-2">
              {[0, 20, 40, 60, 80].map((intensity) => (
                <div key={intensity} className="text-center">
                  <div className="bg-primary/20 rounded h-16 mb-2 flex items-end">
                    <div 
                      className="bg-primary rounded w-full"
                      style={{ 
                        height: `${20 + Math.random() * 80}%` 
                      }}
                    />
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {intensity}-{intensity + 20}%
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Model Performance Metrics */}
      <div className="bg-muted rounded-lg p-4">
        <h3 className="text-sm font-medium text-card-foreground mb-4">
          Model Performance
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Target className="w-4 h-4 text-primary mr-1" />
            </div>
            <div 
              className="text-lg font-bold text-primary"
              data-testid="text-model-precision"
            >
              {metrics.precision.toFixed(1)}%
            </div>
            <div className="text-xs text-muted-foreground">Precision</div>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Activity className="w-4 h-4 text-green-500 mr-1" />
            </div>
            <div 
              className="text-lg font-bold text-green-500"
              data-testid="text-model-recall"
            >
              {metrics.recall.toFixed(1)}%
            </div>
            <div className="text-xs text-muted-foreground">Recall</div>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <TrendingUp className="w-4 h-4 text-orange-500 mr-1" />
            </div>
            <div 
              className="text-lg font-bold text-orange-500"
              data-testid="text-model-f1"
            >
              {metrics.f1Score.toFixed(1)}%
            </div>
            <div className="text-xs text-muted-foreground">F1-Score</div>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Zap className="w-4 h-4 text-yellow-500 mr-1" />
            </div>
            <div 
              className="text-lg font-bold text-yellow-500"
              data-testid="text-model-mse"
            >
              {metrics.mse.toFixed(2)}
            </div>
            <div className="text-xs text-muted-foreground">MSE</div>
          </div>
        </div>
      </div>
    </Card>
  );
}
