import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { useCamera } from "@/hooks/use-camera";
import { useColorAnalysis } from "@/hooks/use-color-analysis";
import { Camera, Settings, Lightbulb, Focus, Aperture } from "lucide-react";

const LIGHT_CONDITIONS = [
  "LED",
  "Daylight", 
  "Fluorescent",
  "Incandescent"
];

export function CameraInterface() {
  const [selectedLightCondition, setSelectedLightCondition] = useState("LED");
  const [exposure, setExposure] = useState([75]);
  const { 
    videoRef, 
    canvasRef, 
    isStreaming, 
    error, 
    startCamera, 
    stopCamera, 
    captureImage,
    updateConfig 
  } = useCamera();
  
  const { analyzeImage, isAnalyzing } = useColorAnalysis();

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, [startCamera, stopCamera]);

  const handleCapture = async () => {
    const captured = await captureImage();
    if (captured) {
      await analyzeImage(captured.imageData, selectedLightCondition);
    }
  };

  const handleFocusChange = (mode: "manual" | "auto") => {
    updateConfig({ focusMode: mode });
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-card-foreground">Live Camera Feed</h2>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-sm text-muted-foreground">
            {isStreaming ? "Recording" : "Offline"}
          </span>
        </div>
      </div>
      
      <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
        {error ? (
          <div className="absolute inset-0 flex items-center justify-center bg-destructive/10">
            <div className="text-center">
              <Camera className="w-12 h-12 text-destructive mx-auto mb-2" />
              <p className="text-sm text-destructive">{error}</p>
              <Button 
                onClick={startCamera} 
                variant="outline" 
                size="sm" 
                className="mt-2"
                data-testid="button-retry-camera"
              >
                Retry
              </Button>
            </div>
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              playsInline
              muted
              data-testid="video-camera-feed"
            />
            <canvas ref={canvasRef} className="hidden" />
            
            {/* Detection Overlay */}
            {isStreaming && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-64 h-32 border-2 border-green-500 rounded-lg flex items-center justify-center bg-background/10 backdrop-blur-sm shadow-lg shadow-green-500/20">
                  <div className="text-center">
                    <Focus className="text-green-500 text-2xl mb-2 mx-auto" />
                    <p className="text-sm text-foreground font-medium">Test Strip Detected</p>
                    <p className="text-xs text-muted-foreground">Ready to analyze</p>
                  </div>
                </div>
              </div>
            )}

            {/* Lighting Controls */}
            <div className="absolute top-4 left-4 bg-card/90 backdrop-blur-sm rounded-lg p-3 border border-border">
              <div className="flex items-center space-x-2 mb-2">
                <Lightbulb className="w-4 h-4 text-yellow-500" />
                <span className="text-sm font-medium">Lighting</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {LIGHT_CONDITIONS.map((condition) => (
                  <Button
                    key={condition}
                    variant={selectedLightCondition === condition ? "default" : "secondary"}
                    size="sm"
                    className="text-xs"
                    onClick={() => setSelectedLightCondition(condition)}
                    data-testid={`button-light-${condition.toLowerCase()}`}
                  >
                    {condition}
                  </Button>
                ))}
              </div>
            </div>

            {/* Capture Button */}
            <div className="absolute bottom-4 right-4">
              <Button
                size="lg"
                className="w-16 h-16 rounded-full border-4 border-background hover:scale-105 transition-transform"
                onClick={handleCapture}
                disabled={!isStreaming || isAnalyzing}
                data-testid="button-capture"
              >
                <Camera className="w-6 h-6" />
              </Button>
            </div>
          </>
        )}
      </div>

      {/* Camera Controls */}
      <div className="flex items-center justify-between mt-4">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Aperture className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Exposure:</span>
            <div className="w-20">
              <Slider
                value={exposure}
                onValueChange={setExposure}
                max={100}
                step={1}
                className="w-full"
                data-testid="slider-exposure"
              />
            </div>
            <span className="text-xs text-muted-foreground">{exposure[0]}%</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Settings className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Focus:</span>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => handleFocusChange("auto")}
              data-testid="button-focus-auto"
            >
              Auto
            </Button>
          </div>
        </div>
        
        <div className="text-sm text-muted-foreground">
          <Badge variant="outline">1920×1080</Badge>
          <span className="ml-2">30 FPS</span>
        </div>
      </div>
    </Card>
  );
}
