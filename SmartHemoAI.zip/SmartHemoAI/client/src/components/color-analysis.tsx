import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Brain, Eye, MapPin } from "lucide-react";
import { useColorAnalysis } from "@/hooks/use-color-analysis";
import type { DetectedColor } from "@shared/schema";

interface ColorSwatchProps {
  color: DetectedColor;
}

function ColorSwatch({ color }: ColorSwatchProps) {
  return (
    <div className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
      <div 
        className="w-8 h-8 rounded-full border-2 border-border transition-all hover:border-primary hover:scale-105"
        style={{ backgroundColor: color.hex }}
        data-testid={`color-swatch-${color.name.toLowerCase()}`}
      />
      <div className="flex-1">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-card-foreground">
            {color.name}
          </span>
          <span className="text-xs text-muted-foreground">
            {color.hex}
          </span>
        </div>
        <div className="text-xs text-muted-foreground">
          Confidence: {color.confidence}%
        </div>
      </div>
    </div>
  );
}

export function ColorAnalysis() {
  const { currentAnalysis, isAnalyzing } = useColorAnalysis();

  if (isAnalyzing) {
    return (
      <Card className="p-6">
        <h2 className="text-lg font-semibold text-card-foreground mb-4">
          Real-time Color Analysis
        </h2>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-sm text-muted-foreground">Analyzing colors...</p>
          </div>
        </div>
      </Card>
    );
  }

  if (!currentAnalysis) {
    return (
      <Card className="p-6">
        <h2 className="text-lg font-semibold text-card-foreground mb-4">
          Real-time Color Analysis
        </h2>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Eye className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-sm text-muted-foreground">
              Capture an image to start analysis
            </p>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <h2 className="text-lg font-semibold text-card-foreground mb-4">
        Real-time Color Analysis
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Detected Colors */}
        <div>
          <h3 className="text-sm font-medium text-card-foreground mb-3">
            Detected Colors
          </h3>
          <div className="space-y-3" data-testid="detected-colors-list">
            {currentAnalysis.detectedColors.map((color, index) => (
              <ColorSwatch key={`${color.hex}-${index}`} color={color} />
            ))}
          </div>
        </div>

        {/* Intensity Analysis */}
        <div>
          <h3 className="text-sm font-medium text-card-foreground mb-3">
            Color Intensity Analysis
          </h3>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-card-foreground">Overall Intensity</span>
                <span 
                  className="text-sm font-medium text-primary"
                  data-testid="text-overall-intensity"
                >
                  {currentAnalysis.overallIntensity}%
                </span>
              </div>
              <Progress 
                value={currentAnalysis.overallIntensity} 
                className="w-full"
                data-testid="progress-intensity"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-muted rounded-lg p-3">
                <div className="text-xs text-muted-foreground mb-1">Light Condition</div>
                <div 
                  className="text-sm font-medium text-card-foreground"
                  data-testid="text-light-condition"
                >
                  {currentAnalysis.lightCondition}
                </div>
              </div>
              <div className="bg-muted rounded-lg p-3">
                <div className="text-xs text-muted-foreground mb-1">Strip Position</div>
                <div 
                  className="text-sm font-medium text-card-foreground"
                  data-testid="text-strip-position"
                >
                  {currentAnalysis.stripPosition}
                </div>
              </div>
            </div>

            <div className="bg-accent rounded-lg p-3">
              <div className="flex items-center space-x-2 mb-2">
                <Brain className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-accent-foreground">
                  AI Prediction
                </span>
              </div>
              <div className="text-xs text-muted-foreground mb-1">
                Glucose Level Range
              </div>
              <div 
                className="text-lg font-bold text-primary"
                data-testid="text-glucose-range"
              >
                {currentAnalysis.glucoseRange}
              </div>
              <div 
                className="text-xs text-green-600"
                data-testid="text-prediction-confidence"
              >
                Confidence: {currentAnalysis.predictionConfidence}%
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
