import { Card } from "@/components/ui/card";
import { Thermometer, Eye, Droplets } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { EnvironmentReading } from "@shared/schema";

interface EnvironmentMetricProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  testId: string;
}

function EnvironmentMetric({ icon, label, value, testId }: EnvironmentMetricProps) {
  return (
    <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
      <div className="flex items-center space-x-3">
        {icon}
        <span className="text-sm text-card-foreground">{label}</span>
      </div>
      <span 
        className="text-sm font-medium text-card-foreground"
        data-testid={testId}
      >
        {value}
      </span>
    </div>
  );
}

export function EnvironmentPanel() {
  const { data: environmentReading } = useQuery<EnvironmentReading>({
    queryKey: ['/api/environment/current'],
  });

  const getDefaultReading = (): EnvironmentReading => ({
    id: "default",
    temperature: "22.0",
    lightIntensity: 850,
    humidity: "45.0",
    timestamp: new Date(),
  });

  const reading = environmentReading || getDefaultReading();

  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold text-card-foreground mb-4">
        Environment
      </h3>
      
      <div className="space-y-4">
        <EnvironmentMetric
          icon={<Thermometer className="w-4 h-4 text-red-500" />}
          label="Temperature"
          value={`${reading.temperature}°C`}
          testId="text-temperature"
        />

        <EnvironmentMetric
          icon={<Eye className="w-4 h-4 text-blue-500" />}
          label="Light Intensity"
          value={`${reading.lightIntensity} lux`}
          testId="text-light-intensity"
        />

        <EnvironmentMetric
          icon={<Droplets className="w-4 h-4 text-cyan-500" />}
          label="Humidity"
          value={`${reading.humidity}%`}
          testId="text-humidity"
        />
      </div>
    </Card>
  );
}
