import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import type { TestResult } from "@shared/schema";

interface ResultItemProps {
  result: TestResult;
}

function ResultItem({ result }: ResultItemProps) {
  const getStatusColor = (glucoseRange?: string | null) => {
    if (!glucoseRange) return "bg-gray-500";
    
    const match = glucoseRange.match(/(\d+)-(\d+)/);
    if (!match) return "bg-gray-500";
    
    const avgGlucose = (parseInt(match[1]) + parseInt(match[2])) / 2;
    
    if (avgGlucose < 80) return "bg-blue-500";
    if (avgGlucose <= 100) return "bg-green-500";
    if (avgGlucose <= 125) return "bg-yellow-500";
    return "bg-red-500";
  };

  const getStatusLabel = (glucoseRange?: string | null) => {
    if (!glucoseRange) return "Unknown";
    
    const match = glucoseRange.match(/(\d+)-(\d+)/);
    if (!match) return "Unknown";
    
    const avgGlucose = (parseInt(match[1]) + parseInt(match[2])) / 2;
    
    if (avgGlucose < 80) return "Low";
    if (avgGlucose <= 100) return "Normal";
    if (avgGlucose <= 125) return "Elevated";
    return "High";
  };

  const statusColor = getStatusColor(result.glucoseRange);
  const statusLabel = getStatusLabel(result.glucoseRange);
  const timeAgo = formatDistanceToNow(new Date(result.timestamp), { addSuffix: true });

  return (
    <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
      <div>
        <div 
          className="text-sm font-medium text-card-foreground"
          data-testid={`text-result-value-${result.id}`}
        >
          {result.glucoseRange || "No result"}
        </div>
        <div 
          className="text-xs text-muted-foreground"
          data-testid={`text-result-timestamp-${result.id}`}
        >
          {timeAgo}
        </div>
      </div>
      <div className="flex items-center space-x-2">
        <div className={`w-2 h-2 ${statusColor} rounded-full`}></div>
        <Badge 
          variant="secondary" 
          className="text-xs"
          data-testid={`badge-result-status-${result.id}`}
        >
          {statusLabel}
        </Badge>
      </div>
    </div>
  );
}

export function ResultsPanel() {
  const { data: testResults = [] } = useQuery<TestResult[]>({
    queryKey: ['/api/test-results'],
  });

  const recentResults = testResults.slice(0, 5);

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-card-foreground">
          Recent Results
        </h3>
        <Button 
          variant="ghost" 
          size="sm"
          data-testid="button-view-all-results"
        >
          View All
        </Button>
      </div>

      <div className="space-y-3" data-testid="recent-results-list">
        {recentResults.length > 0 ? (
          recentResults.map((result) => (
            <ResultItem key={result.id} result={result} />
          ))
        ) : (
          <div className="text-center py-8">
            <p className="text-sm text-muted-foreground">
              No test results yet
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Capture an image to start testing
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}
