import { Screen } from '@shared/types';
import { useColorAnalysis } from '@/hooks/use-color-analysis';
import Card from '@/components/Card';

interface ResultsScreenProps {
  setCurrentScreen: (screen: Screen) => void;
  testType: string | null;
}

const ResultsScreen: React.FC<ResultsScreenProps> = ({ setCurrentScreen, testType }) => {
  const { currentAnalysis } = useColorAnalysis();

  if (!currentAnalysis) {
    return (
      <div className="flex flex-col items-center justify-center h-full bg-surface-light dark:bg-surface-dark p-6">
        <p className="text-text-lightMuted dark:text-text-darkMuted">No analysis results available</p>
        <button onClick={() => setCurrentScreen(Screen.Camera)} className="mt-4 px-6 py-2 bg-primary-default text-white rounded-lg">
          Take New Test
        </button>
      </div>
    );
  }

  const match = currentAnalysis.glucoseRange?.match(/(\d+)-(\d+)/);
  const avgGlucose = match ? 
    (parseInt(match[1] || '0') + parseInt(match[2] || '0')) / 2 : 0;
  const isNormal = avgGlucose >= 70 && avgGlucose <= 100;

  return (
    <div className="flex flex-col h-full bg-surface-light dark:bg-surface-dark p-6 space-y-6">
      <header>
        <h1 className="text-3xl font-bold text-text-light dark:text-text-dark text-center">Test Results</h1>
        <p className="text-center text-text-lightMuted dark:text-text-darkMuted">{testType || "Glucose Test"}</p>
      </header>

      <Card className="text-center">
        <h3 className="text-lg font-bold text-text-light dark:text-text-dark mb-4">AI Interpretation</h3>
        <div className={`inline-flex items-center space-x-2 px-6 py-3 rounded-full ${isNormal ? 'bg-green-100 dark:bg-green-900' : 'bg-yellow-100 dark:bg-yellow-900'}`}>
          <span className={`w-4 h-4 rounded-full ${isNormal ? 'bg-green-500' : 'bg-yellow-500'}`}></span>
          <p className={`text-2xl font-extrabold ${isNormal ? 'text-green-600 dark:text-green-300' : 'text-yellow-600 dark:text-yellow-300'}`}>
            {isNormal ? "Normal" : "Check Required"}
          </p>
        </div>
        <div className="mt-4 space-y-2">
          <p className="text-2xl font-bold text-primary-default">{currentAnalysis.glucoseRange}</p>
          <p className="text-sm text-text-lightMuted dark:text-text-darkMuted">
            Confidence: {currentAnalysis.predictionConfidence}%
          </p>
        </div>
      </Card>
      
      <Card>
        <h3 className="text-lg font-bold text-text-light dark:text-text-dark mb-3">Detected Colors</h3>
        <div className="space-y-3">
          {currentAnalysis.detectedColors.map((color, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-full border-2 border-white dark:border-gray-600 shadow-sm" style={{ backgroundColor: color.hex }}></div>
                <div>
                  <p className="font-semibold text-text-light dark:text-text-dark">{color.name}</p>
                  <p className="text-xs text-text-lightMuted dark:text-text-darkMuted">{color.hex}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-primary-default">{color.intensity}%</p>
                <p className="text-xs text-text-lightMuted dark:text-text-darkMuted">{color.confidence}% conf</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <h3 className="text-lg font-bold text-text-light dark:text-text-dark mb-2">Test Conditions</h3>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <p className="text-text-lightMuted dark:text-text-darkMuted">Light Condition</p>
            <p className="font-semibold text-text-light dark:text-text-dark">{currentAnalysis.lightCondition}</p>
          </div>
          <div>
            <p className="text-text-lightMuted dark:text-text-darkMuted">Strip Position</p>
            <p className="font-semibold text-text-light dark:text-text-dark">{currentAnalysis.stripPosition}</p>
          </div>
          <div>
            <p className="text-text-lightMuted dark:text-text-darkMuted">Overall Intensity</p>
            <p className="font-semibold text-text-light dark:text-text-dark">{currentAnalysis.overallIntensity}%</p>
          </div>
          <div>
            <p className="text-text-lightMuted dark:text-text-darkMuted">Analysis Time</p>
            <p className="font-semibold text-text-light dark:text-text-dark">{new Date().toLocaleTimeString()}</p>
          </div>
        </div>
      </Card>

      <div className="flex-grow"></div>

      <div className="space-y-3">
        <button 
          onClick={() => setCurrentScreen(Screen.Report)}
          className="w-full py-4 bg-primary-default text-white font-bold rounded-xl shadow-md hover:bg-primary-dark transition-colors"
        >
          Save Report
        </button>
        <button 
          onClick={() => setCurrentScreen(Screen.Camera)}
          className="w-full py-3 text-primary-default font-bold rounded-lg hover:bg-primary-light dark:hover:bg-primary-dark/20 transition-colors"
        >
          Take Another Test
        </button>
      </div>
    </div>
  );
};

export default ResultsScreen;
