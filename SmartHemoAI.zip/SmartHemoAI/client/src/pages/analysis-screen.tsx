import { useEffect, useState } from 'react';
import { Screen } from '@shared/types';
import { useColorAnalysis } from '@/hooks/use-color-analysis';

interface AnalysisScreenProps {
  setCurrentScreen: (screen: Screen) => void;
}

const AnalysisScreen: React.FC<AnalysisScreenProps> = ({ setCurrentScreen }) => {
  const [progress, setProgress] = useState(0);
  const { isAnalyzing } = useColorAnalysis();

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(oldProgress => {
        if (oldProgress === 100) {
          clearInterval(timer);
          setTimeout(() => setCurrentScreen(Screen.Results), 500);
          return 100;
        }
        const diff = Math.random() * 10;
        return Math.min(oldProgress + diff, 100);
      });
    }, 200);

    return () => {
      clearInterval(timer);
    };
  }, [setCurrentScreen]);

  return (
    <div className="flex flex-col items-center justify-center h-full bg-gradient-to-br from-primary-light to-white dark:from-primary-dark/20 dark:to-background-dark p-8">
      <div className="w-48 h-48 border-4 border-dashed border-primary-default rounded-full animate-spin flex items-center justify-center">
        <div className="w-32 h-32 bg-white dark:bg-gray-800 rounded-full flex items-center justify-center shadow-lg">
          <svg className="w-16 h-16 text-primary-default" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 10.5a.5.5 0 11-1 0 .5.5 0 011 0zM14 14.5a.5.5 0 11-1 0 .5.5 0 011 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
        </div>
      </div>
      <h2 className="text-2xl font-bold text-text-light dark:text-text-dark mt-8">Analyzing Test Strip...</h2>
      <p className="text-text-lightMuted dark:text-text-darkMuted mt-2 text-center">
        {isAnalyzing ? 'AI is processing the image' : 'Detecting colors and intensity'}
      </p>
      <div className="w-full max-w-xs bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mt-12">
        <div className="bg-primary-default h-2.5 rounded-full transition-all duration-300" style={{ width: `${progress}%` }}></div>
      </div>
      <p className="text-sm font-semibold text-primary-dark dark:text-primary-light mt-2">{Math.round(progress)}%</p>
      <div className="mt-8 space-y-2 text-sm text-text-lightMuted dark:text-text-darkMuted text-center">
        <p>✓ Strip detection complete</p>
        <p>✓ Color extraction in progress</p>
        <p>✓ Light condition classification</p>
        <p className="text-primary-default font-medium">• Predicting glucose levels...</p>
      </div>
    </div>
  );
};

export default AnalysisScreen;
