import { Screen, TestType } from '@shared/types';
import BottomNav from '@/components/BottomNav';
import StethoscopeIcon from '@/components/icons/StethoscopeIcon';
import Card from '@/components/Card';
import GlucoseIcon from '@/components/icons/GlucoseIcon';
import CbcIcon from '@/components/icons/CbcIcon';
import HemoglobinIcon from '@/components/icons/HemoglobinIcon';

interface HomeScreenProps {
  setCurrentScreen: (screen: Screen) => void;
  setSelectedTest: (test: TestType) => void;
}

const TestCard: React.FC<{
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
}> = ({ icon, title, description, onClick }) => {
  return (
    <Card onClick={onClick} className="flex items-center space-x-4">
      <div className="text-primary-default p-3 bg-primary-light rounded-full">{icon}</div>
      <div>
        <h3 className="text-lg font-bold text-text-light dark:text-text-dark">{title}</h3>
        <p className="text-sm text-text-lightMuted dark:text-text-darkMuted">{description}</p>
      </div>
    </Card>
  );
};

const HomeScreen: React.FC<HomeScreenProps> = ({ setCurrentScreen, setSelectedTest }) => {
  const handleTestSelection = (testType: TestType) => {
    setSelectedTest(testType);
    setCurrentScreen(Screen.PatientDetails);
  };
    
  return (
    <div className="flex flex-col h-full bg-surface-light dark:bg-surface-dark">
      <header className="p-6">
        <div className="flex items-center space-x-2">
          <StethoscopeIcon className="w-8 h-8 text-primary-default" />
          <h1 className="text-2xl font-bold text-text-light dark:text-text-dark">GK SmartHemo</h1>
        </div>
        <p className="text-text-lightMuted dark:text-text-darkMuted mt-1">AI-powered test strip analysis</p>
      </header>
      
      <main className="flex-grow p-6 space-y-4 overflow-y-auto pb-24">
        <h2 className="text-xl font-semibold text-text-light dark:text-text-dark">Available Tests</h2>
        <TestCard 
          icon={<GlucoseIcon className="w-8 h-8" />} 
          title="Glucose Test" 
          description="AI-powered color intensity analysis"
          onClick={() => handleTestSelection(TestType.Glucose)}
        />
        <TestCard 
          icon={<CbcIcon className="w-8 h-8" />} 
          title="Complete Blood Count" 
          description="Multi-parameter blood analysis"
          onClick={() => handleTestSelection(TestType.CBC)}
        />
        <TestCard 
          icon={<HemoglobinIcon className="w-8 h-8" />} 
          title="Hemoglobin" 
          description="Oxygen-carrying protein measurement"
          onClick={() => handleTestSelection(TestType.Hemoglobin)}
        />
      </main>

      <BottomNav activeScreen={Screen.Home} setCurrentScreen={setCurrentScreen} />
    </div>
  );
};

export default HomeScreen;
