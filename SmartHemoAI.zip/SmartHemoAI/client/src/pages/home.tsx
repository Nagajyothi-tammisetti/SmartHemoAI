import { useEffect } from "react";
import { Settings, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CameraInterface } from "@/components/camera-interface";
import { ColorAnalysis } from "@/components/color-analysis";
import { CalibrationPanel } from "@/components/calibration-panel";
import { EnvironmentPanel } from "@/components/environment-panel";
import { ResultsPanel } from "@/components/results-panel";
import { DatasetVisualization } from "@/components/dataset-visualization";
import { initializeModels } from "@/lib/tensorflow-models";

export default function Home() {
  useEffect(() => {
    // Initialize ML models on component mount
    initializeModels().catch(console.error);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <svg
                  className="w-6 h-6 text-primary-foreground"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 2L3.09 8.26L4 21L12 17L20 21L20.91 8.26L12 2Z" />
                </svg>
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">SmartHemo</h1>
                <p className="text-xs text-muted-foreground">
                  AI-Powered Test Strip Analysis
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                size="sm"
                data-testid="button-settings"
              >
                <Settings className="w-4 h-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm"
                data-testid="button-profile"
              >
                <User className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content - Camera and Analysis */}
          <div className="lg:col-span-2 space-y-6">
            <CameraInterface />
            <ColorAnalysis />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <CalibrationPanel />
            <EnvironmentPanel />
            <ResultsPanel />
          </div>
        </div>

        {/* Dataset Visualization */}
        <div className="mt-6">
          <DatasetVisualization />
        </div>
      </main>
    </div>
  );
}
