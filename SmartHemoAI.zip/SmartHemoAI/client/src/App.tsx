import { useState, useEffect } from 'react';
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Screen, PatientDetails, TestType } from '@shared/types';
import { initializeModels } from '@/lib/tensorflow-models';
import SplashScreen from '@/pages/splash';
import HomeScreen from '@/pages/home-screen';
import PatientDetailsScreen from '@/pages/patient-details';
import CameraScreen from '@/pages/camera-screen';
import AnalysisScreen from '@/pages/analysis-screen';
import ResultsScreen from '@/pages/results-screen';
import ReportScreen from '@/pages/report';
import SettingsScreen from '@/pages/settings-screen';

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.Splash);
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [selectedTest, setSelectedTest] = useState<TestType | null>(null);
  const [patientDetails, setPatientDetails] = useState<PatientDetails | null>(null);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  useEffect(() => {
    initializeModels().catch(console.error);
  }, []);

  const renderScreen = () => {
    switch (currentScreen) {
      case Screen.Splash:
        return <SplashScreen setCurrentScreen={setCurrentScreen} />;
      case Screen.Home:
        return <HomeScreen setCurrentScreen={setCurrentScreen} setSelectedTest={setSelectedTest} />;
      case Screen.PatientDetails:
        return <PatientDetailsScreen setCurrentScreen={setCurrentScreen} setPatientDetails={setPatientDetails} />;
      case Screen.Camera:
        return <CameraScreen setCurrentScreen={setCurrentScreen} />;
      case Screen.Analysis:
        return <AnalysisScreen setCurrentScreen={setCurrentScreen} />;
      case Screen.Results:
        return <ResultsScreen setCurrentScreen={setCurrentScreen} testType={selectedTest} />;
      case Screen.Report:
        return <ReportScreen setCurrentScreen={setCurrentScreen} testType={selectedTest} patientDetails={patientDetails} />;
      case Screen.Settings:
        return <SettingsScreen setCurrentScreen={setCurrentScreen} darkMode={darkMode} setDarkMode={setDarkMode} />;
      default:
        return <HomeScreen setCurrentScreen={setCurrentScreen} setSelectedTest={setSelectedTest} />;
    }
  };

  return (
    <QueryClientProvider client={queryClient}>
      <div className="bg-background-light dark:bg-background-dark min-h-screen font-sans">
        <div className="w-full max-w-md mx-auto h-screen shadow-2xl bg-surface-light dark:bg-surface-dark overflow-hidden">
          {renderScreen()}
        </div>
      </div>
    </QueryClientProvider>
  );
}

export default App;
