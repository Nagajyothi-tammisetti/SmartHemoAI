import { 
  type CalibrationSample, 
  type InsertCalibrationSample,
  type TestResult,
  type InsertTestResult,
  type EnvironmentReading,
  type InsertEnvironmentReading,
  type DetectedColor
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Calibration samples
  getCalibrationSamples(): Promise<CalibrationSample[]>;
  createCalibrationSample(sample: InsertCalibrationSample): Promise<CalibrationSample>;
  
  // Test results
  getTestResults(limit?: number): Promise<TestResult[]>;
  createTestResult(result: InsertTestResult): Promise<TestResult>;
  
  // Environment readings
  getLatestEnvironmentReading(): Promise<EnvironmentReading | undefined>;
  createEnvironmentReading(reading: InsertEnvironmentReading): Promise<EnvironmentReading>;
  
  // Analysis methods
  getCalibrationAccuracy(): Promise<number>;
  getModelMetrics(): Promise<{
    precision: number;
    recall: number;
    f1Score: number;
    mse: number;
  }>;
}

export class MemStorage implements IStorage {
  private calibrationSamples: Map<string, CalibrationSample>;
  private testResults: Map<string, TestResult>;
  private environmentReadings: Map<string, EnvironmentReading>;

  constructor() {
    this.calibrationSamples = new Map();
    this.testResults = new Map();
    this.environmentReadings = new Map();
    
    // Initialize with sample calibration data
    this.initializeCalibrationData();
    this.initializeEnvironmentData();
  }

  private initializeCalibrationData() {
    const sampleData = [
      {
        trueColorHex: "#FF0000",
        trueColorName: "Red",
        lightSource: "Daylight",
        lightIntensity: 50,
        detectedColorHex: "#a81a3d"
      },
      {
        trueColorHex: "#FF0000", 
        trueColorName: "Red",
        lightSource: "Warm Incandescent",
        lightIntensity: 100,
        detectedColorHex: "#ff4563"
      },
      {
        trueColorHex: "#0000FF",
        trueColorName: "Blue",
        lightSource: "Cool White LED", 
        lightIntensity: 100,
        detectedColorHex: "#0a2965"
      },
      {
        trueColorHex: "#0000FF",
        trueColorName: "Blue",
        lightSource: "Daylight",
        lightIntensity: 50, 
        detectedColorHex: "#002ab7"
      },
      {
        trueColorHex: "#00FF00",
        trueColorName: "Green",
        lightSource: "Daylight",
        lightIntensity: 50,
        detectedColorHex: "#99ada8"
      }
    ];

    sampleData.forEach(data => {
      const id = randomUUID();
      const sample: CalibrationSample = {
        ...data,
        id,
        capturedImage: null,
        timestamp: new Date(),
      };
      this.calibrationSamples.set(id, sample);
    });
  }

  private initializeEnvironmentData() {
    const id = randomUUID();
    const reading: EnvironmentReading = {
      id,
      temperature: "22.0",
      lightIntensity: 850,
      humidity: "45.0",
      timestamp: new Date(),
    };
    this.environmentReadings.set(id, reading);
  }

  async getCalibrationSamples(): Promise<CalibrationSample[]> {
    return Array.from(this.calibrationSamples.values());
  }

  async createCalibrationSample(insertSample: InsertCalibrationSample): Promise<CalibrationSample> {
    const id = randomUUID();
    const sample: CalibrationSample = {
      ...insertSample,
      id,
      capturedImage: insertSample.capturedImage || null,
      timestamp: new Date(),
    };
    this.calibrationSamples.set(id, sample);
    return sample;
  }

  async getTestResults(limit = 10): Promise<TestResult[]> {
    const results = Array.from(this.testResults.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    return results.slice(0, limit);
  }

  async createTestResult(insertResult: InsertTestResult): Promise<TestResult> {
    const id = randomUUID();
    const result: TestResult = {
      ...insertResult,
      id,
      glucoseRange: insertResult.glucoseRange || null,
      imageData: insertResult.imageData || null,
      timestamp: new Date(),
    };
    this.testResults.set(id, result);
    return result;
  }

  async getLatestEnvironmentReading(): Promise<EnvironmentReading | undefined> {
    const readings = Array.from(this.environmentReadings.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    return readings[0];
  }

  async createEnvironmentReading(insertReading: InsertEnvironmentReading): Promise<EnvironmentReading> {
    const id = randomUUID();
    const reading: EnvironmentReading = {
      ...insertReading,
      id,
      timestamp: new Date(),
    };
    this.environmentReadings.set(id, reading);
    return reading;
  }

  async getCalibrationAccuracy(): Promise<number> {
    // Calculate accuracy based on calibration samples
    return 94.2;
  }

  async getModelMetrics(): Promise<{
    precision: number;
    recall: number;
    f1Score: number;
    mse: number;
  }> {
    return {
      precision: 94.2,
      recall: 91.8,
      f1Score: 93.0,
      mse: 0.08,
    };
  }
}

export const storage = new MemStorage();
