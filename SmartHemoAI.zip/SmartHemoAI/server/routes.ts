import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertCalibrationSampleSchema,
  insertTestResultSchema,
  insertEnvironmentReadingSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Calibration samples endpoints
  app.get("/api/calibration-samples", async (_req, res) => {
    try {
      const samples = await storage.getCalibrationSamples();
      res.json(samples);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch calibration samples" });
    }
  });

  app.post("/api/calibration-samples", async (req, res) => {
    try {
      const data = insertCalibrationSampleSchema.parse(req.body);
      const sample = await storage.createCalibrationSample(data);
      res.status(201).json(sample);
    } catch (error) {
      res.status(400).json({ message: "Invalid calibration sample data" });
    }
  });

  // Test results endpoints
  app.get("/api/test-results", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const results = await storage.getTestResults(limit);
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch test results" });
    }
  });

  app.post("/api/test-results", async (req, res) => {
    try {
      const data = insertTestResultSchema.parse(req.body);
      const result = await storage.createTestResult(data);
      res.status(201).json(result);
    } catch (error) {
      res.status(400).json({ message: "Invalid test result data" });
    }
  });

  // Environment readings endpoints
  app.get("/api/environment/current", async (_req, res) => {
    try {
      const reading = await storage.getLatestEnvironmentReading();
      res.json(reading);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch environment reading" });
    }
  });

  app.post("/api/environment", async (req, res) => {
    try {
      const data = insertEnvironmentReadingSchema.parse(req.body);
      const reading = await storage.createEnvironmentReading(data);
      res.status(201).json(reading);
    } catch (error) {
      res.status(400).json({ message: "Invalid environment reading data" });
    }
  });

  // Analysis endpoints
  app.get("/api/calibration/accuracy", async (_req, res) => {
    try {
      const accuracy = await storage.getCalibrationAccuracy();
      res.json({ accuracy });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch calibration accuracy" });
    }
  });

  app.get("/api/model/metrics", async (_req, res) => {
    try {
      const metrics = await storage.getModelMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch model metrics" });
    }
  });

  // Image processing endpoint for color analysis
  app.post("/api/analyze-image", async (req, res) => {
    try {
      const { imageData, lightCondition } = req.body;
      
      if (!imageData) {
        return res.status(400).json({ message: "Image data is required" });
      }

      // TODO: Implement actual image processing and color analysis
      // For now, return mock analysis results
      const analysisResult = {
        detectedColors: [
          { name: "Red", hex: "#FF4563", confidence: 94, intensity: 76 },
          { name: "Blue", hex: "#0A2965", confidence: 87, intensity: 54 },
          { name: "Green", hex: "#00A000", confidence: 91, intensity: 71 }
        ],
        overallIntensity: 76,
        lightCondition: lightCondition || "Cool White LED",
        stripPosition: "Centered",
        glucoseRange: "85-95 mg/dL",
        predictionConfidence: 92
      };

      res.json(analysisResult);
    } catch (error) {
      res.status(500).json({ message: "Failed to analyze image" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
